from django.core.validators import MinLengthValidator, EmailValidator
from django.db import models
from django.utils import timezone
from hospital.models import Doctor
from django.core.exceptions import ValidationError

class Appointment(models.Model):
    time_choices = (
        ('morning', "Morning"),
        ('evening', "Evening")
    )
    
    # Validators
    name_validator = MinLengthValidator(limit_value=3, message="Name must have at least 3 characters.")
    phone_validator = MinLengthValidator(limit_value=10, message="Phone number must have at least 10 digits.")
    email_validator = EmailValidator(message="Enter a valid email address.")
    
    name = models.CharField(max_length=120, validators=[name_validator])
    phone = models.CharField(max_length=20, validators=[phone_validator])
    email = models.EmailField(validators=[email_validator])
    doctor = models.ForeignKey(
        Doctor, on_delete=models.CASCADE, related_name='appointments')
    date = models.DateField(default=timezone.now)
    time = models.CharField(choices=time_choices, max_length=10)
    note = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name}-{self.doctor.name}"
    def clean(self):
        # Check if the entered email already exists in the database
        existing_appointment_on_date = Appointment.objects.filter(email__iexact=self.email, date__iexact=self.date).first()
        if existing_appointment_on_date and existing_appointment_on_date.pk != self.pk:
            raise ValidationError("An appointment with this email already exists on the selected date.")
