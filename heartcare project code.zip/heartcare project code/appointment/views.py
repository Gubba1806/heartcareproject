from django.contrib import messages
from django.core.exceptions import ValidationError
from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import View
from hospital.models import Doctor
from .models import Appointment
from django.conf import settings
from django.core.mail import send_mail

class AppointmentView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'doctors': Doctor.objects.all()
        }
        return render(request, "appointment/index.html", context)

    def post(self, request, *args, **kwargs):
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        doctor_id = request.POST.get('doctor')
        date = request.POST.get('date')
        time = request.POST.get('time')
        note = request.POST.get('note')
        if doctor_id:
            doctor = get_object_or_404(Doctor, id=doctor_id)
        subject='heart care'
        message=f'Thank you for booking an appoinment. your booking date is on {date} with {doctor} in the {time} session. Please be before the time'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email, ]    

        if(name and phone and email and doctor and date and time):
            try:
                # Validate the appointment object before saving
                appointment = Appointment(
                    name=name, phone=phone, email=email, doctor=doctor, date=date, time=time, note=note
                )
                appointment.full_clean()
            except ValidationError as e:
                messages.error(request, str(e))
            else:
                # Save the appointment if validation passes
                appointment.save()
                send_mail(subject, message, email_from, recipient_list)
                messages.success(request, 'Appointment done successfully')
        return redirect('appointment')


def appoinments(request):
    return render(request,'appointment/index.html')
def contact(request):
    return render(request,'hospital/contact.html')
